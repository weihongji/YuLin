Folder used to store release packages.

18:40 2017/3/13